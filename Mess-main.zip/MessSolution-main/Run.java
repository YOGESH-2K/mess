import MyClasses.SignIn;
import MyClasses.SignUp;
import MyClasses.TermsAndConditions;
import MyClasses.HomePage;
import MyClasses.AddParticipant;
import MyClasses.MyProfile;
import MyClasses.CreateMess;
import MyClasses.UtilityBills;
import MyClasses.ShowFinalCalculation;
import MyInterfaces.tempFileHandler;

public class Run {
    public static void main(String args[]) {
        new SignIn();

    }
}
