package MyInterfaces;

import java.io.File;

public interface tempFileHandler {
    void deleteTempFile(File file);

}